package com.example.football.config;


public class ApplicationBeanConfiguration {
}
